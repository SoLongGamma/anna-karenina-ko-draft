"""Compose the Korean title over the separately saved cover painting."""

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent
ART = ROOT / "cover-art.png"
OUTPUT = ROOT / "cover.jpg"
FONT = "/System/Library/Fonts/Supplemental/AppleMyungjo.ttf"

image = Image.open(ART).convert("RGB")
draw = ImageDraw.Draw(image)
width, height = image.size
cream = (245, 232, 204)
gold = (201, 161, 99)

title_font = ImageFont.truetype(FONT, 104)
author_font = ImageFont.truetype(FONT, 40)
edition_font = ImageFont.truetype(FONT, 24)

for text, y in (("안나", 78), ("카레니나", 185)):
    box = draw.textbbox((0, 0), text, font=title_font)
    x = (width - (box[2] - box[0])) / 2
    draw.text((x, y), text, font=title_font, fill=cream,
              stroke_width=1, stroke_fill=(79, 42, 40))

draw.line((width * .34, 337, width * .66, 337), fill=gold, width=2)

author = "레프 톨스토이"
box = draw.textbbox((0, 0), author, font=author_font)
draw.text(((width - (box[2] - box[0])) / 2, height - 178), author,
          font=author_font, fill=cream, stroke_width=1,
          stroke_fill=(53, 25, 24))

edition = "한국어 읽기 배치 · 삽화판"
box = draw.textbbox((0, 0), edition, font=edition_font)
draw.text(((width - (box[2] - box[0])) / 2, height - 105), edition,
          font=edition_font, fill=gold)

image.save(OUTPUT, quality=92, optimize=True, subsampling=0)
print(OUTPUT)
