from pathlib import Path
import shutil


root = Path('/LOCAL_USER/Documents/ChatGPT/문제해결/anna-karenina-structured')
readme = root / 'README.md'
content = readme.read_text(encoding='utf-8')
entry = '- 2026-10-08 검증: 239장 본문과 목차 239개, 삽화 30장, 모든 이미지 참조, EPUB ZIP/XML 구조를 확인했습니다. 제1부 제14장 미리보기에서 그림 뒤 본문의 들여쓰기와 읽기 폭을 화면으로 확인했습니다.\n'
assert entry not in content
readme.write_text(content + entry, encoding='utf-8')
shutil.copy2(root / '안나_카레니나_전권_읽기배치.epub',
             root / '안나_카레니나_읽기배치_작업본.epub')
print('Verification log appended; working EPUB synchronized.')
