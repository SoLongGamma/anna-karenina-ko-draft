from pathlib import Path
import shutil


root = Path('/LOCAL_USER/Documents/ChatGPT/문제해결/anna-karenina-structured')
readme = root / 'README.md'
text = readme.read_text(encoding='utf-8')
entry = '''\n## 수정 기록\n\n- 2026-10-08: 8개 부의 첫 장에만 《안나 카레니나》와 레프 톨스토이 표기를 남기고, 나머지 231개 장의 반복 표기를 제거했습니다. 장별 HTML과 239장 전권 EPUB를 다시 만들고, 제목·저자 표기가 각각 8곳인지와 EPUB ZIP/XML 구조를 확인했습니다. 기존 번역, 삽화, 이전 기록은 보존했습니다.\n'''
assert '## 수정 기록' not in text
readme.write_text(text + entry, encoding='utf-8')
shutil.copy2(root / '안나_카레니나_전권_읽기배치.epub',
             root / '안나_카레니나_읽기배치_작업본.epub')
print('Appended change log; synchronized working EPUB.')
