from pathlib import Path
from PIL import Image
import json
import shutil
import sys

ROOT = Path('/LOCAL_USER/Documents/ChatGPT/문제해결/anna-karenina-structured')
MANIFEST = Path(__file__).with_name('anna_priority_scenes.json')
rank = int(sys.argv[1])
source = Path(sys.argv[2]) if len(sys.argv) > 2 else None
items = json.loads(MANIFEST.read_text(encoding='utf-8'))
item = next(x for x in items if x['rank'] == rank)
record_path = ROOT / 'illustrations.json'
records = json.loads(record_path.read_text(encoding='utf-8'))
if rank == 1:
    old = next(x for x in records if x['id'] == item['existing_id'])
    old['feature_rank'] = 1
else:
    assert source and source.is_file(), source
    chapter_file = ROOT / f"제{item['part']}부_제{item['chapter']}장.md"
    assert chapter_file.is_file()
    groups = [x for x in chapter_file.read_text(encoding='utf-8').split('\n\n')
              if x.strip() and not x.lstrip().startswith(('#', '>'))]
    assert item['after_group'] <= len(groups), (rank, len(groups))
    item_id = f"p{item['part']:02d}-c{item['chapter']:02d}-g{item['after_group']:02d}"
    assert not any(x['id'] == item_id for x in records), item_id
    base = f"{item_id}-{item['slug']}"
    png = ROOT / 'illustrations' / f'{base}.png'
    jpg = ROOT / 'illustrations' / f'{base}.jpg'
    assert not png.exists() and not jpg.exists()
    shutil.copy2(source, png)
    with Image.open(source) as im:
        im.convert('RGB').save(jpg, 'JPEG', quality=85, optimize=True)
    records.append({'id': item_id, 'chapter_file': chapter_file.name,
                    'after_group': item['after_group'],
                    'file': f'illustrations/{jpg.name}',
                    'scene': item['scene'], 'alt': item['alt'],
                    'feature_rank': rank})
records.sort(key=lambda x: (int(x['chapter_file'].split('부_')[0][1:]),
                            int(x['chapter_file'].split('제')[-1].split('장')[0]),
                            x['after_group'], x.get('feature_rank', 0)))
record_path.write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n',
                       encoding='utf-8')
print(f'priority {rank} registered; total {len(records)}')
