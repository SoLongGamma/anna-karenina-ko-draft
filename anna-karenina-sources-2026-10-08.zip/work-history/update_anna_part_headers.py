from pathlib import Path
import re


ROOT = Path('/LOCAL_USER/Documents/ChatGPT/문제해결/anna-karenina-structured')
HEADER = '# 안나 카레니나\n\n레프 톨스토이\n\n'
sources = list(ROOT.glob('제*부_제*장.md'))
assert len(sources) == 239, f'Expected 239 chapters, found {len(sources)}'

changed = 0
for source in sources:
    match = re.fullmatch(r'제([1-8])부_제(\d+)장\.md', source.name)
    assert match, source.name
    chapter = int(match.group(2))
    content = source.read_text(encoding='utf-8')
    assert content.startswith(HEADER), source.name
    if chapter != 1:
        source.write_text(content[len(HEADER):], encoding='utf-8')
        changed += 1

assert changed == 231, changed
readme = ROOT / 'README.md'
content = readme.read_text(encoding='utf-8')
anchor = '## 배치 원칙\n'
assert content.count(anchor) == 1
content = content.replace(anchor, '각 부의 첫 장에만 작품명과 저자명을 표시합니다. 다른 장은 장 제목부터 시작합니다.\n\n' + anchor)
readme.write_text(content, encoding='utf-8')
print(f'Updated {changed} chapter headings; retained 8 part openings.')
