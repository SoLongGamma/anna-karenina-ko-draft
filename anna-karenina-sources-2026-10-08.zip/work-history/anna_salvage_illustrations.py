from pathlib import Path
from PIL import Image
import json
import shutil
import sys


ROOT = Path('/LOCAL_USER/Documents/ChatGPT/문제해결/anna-karenina-structured')
GENERATED = Path('/LOCAL_USER/.codex/generated_images/01a116e9-eed1-7522-b9d9-8d9561590ad0')
ITEMS = [
    ('exec-326917fd-f9a5-4759-a75b-a99ddb08622d.png', 11, 13, 'levin-vronsky-news',
     '스티바에게 브론스키의 구애를 듣고 창백해진 레빈',
     '식당에서 스티바의 말을 듣고 레빈이 창백한 얼굴로 의자에 기대 앉는다'),
    ('exec-d8c33cde-d773-4bdc-91fc-4ecf8b8f4101.png', 12, 17, 'princess-worries',
     '키티의 혼사를 두고 홀로 걱정하는 셰르바츠카야 공작부인',
     '공작부인이 겨울 창가에 앉아 키티의 초상화를 곁에 두고 생각에 잠긴다'),
    ('exec-d711d476-47a9-4ce2-a31f-62a36abe9621.png', 12, 28, 'kitty-mother',
     '혼사 이야기에 눈물이 고인 키티를 다독이는 어머니',
     '공작부인이 눈물을 참는 키티의 손을 잡고 다정하게 바라본다'),
    ('exec-2bca3ff2-545f-4c42-8f78-752ad6f1e092.png', 13, 13, 'levin-arrives-early',
     '청혼하려 일찍 찾아와 키티와 단둘이 마주 선 레빈',
     '텅 빈 응접실에서 모자를 든 레빈과 키티가 서로 떨어져 마주 선다'),
    ('exec-3b559120-c5d2-4a34-801c-39c6eb729474.png', 13, 24, 'kitty-refuses-levin',
     '레빈의 청혼을 거절하며 고개를 숙인 키티',
     '키티가 고개를 숙이고 레빈은 말을 잃은 채 그녀 앞에 서 있다'),
    ('exec-2aef8d47-e6e1-49f2-9a60-1714906bb5a5.png', 14, 23, 'vronsky-enters',
     '브론스키가 들어오자 빛나는 눈으로 바라보는 키티와 그 모습을 보는 레빈',
     '군복 차림 브론스키가 응접실에 들어오고 키티가 그를 바라보는 동안 레빈은 옆에서 지켜본다'),
    ('exec-47fa534c-8760-4695-a8c2-26c7bf937d0f.png', 14, 56, 'spiritualism-debate',
     '작은 탁자를 둘러싼 강신술 논쟁에서 맞서는 레빈과 브론스키',
     '응접실의 작은 탁자 앞에서 레빈이 열띠게 말하고 브론스키와 손님들이 듣는다'),
    ('/LOCAL_USER/.codex/generated_images/01a11967-8d82-7721-ab33-6b1408d60b6b/exec-15abd4fc-4cc1-4539-a610-d82941efde65.png', 14, 66, 'kitty-levin-glance',
     '탁자로 가던 키티와 떠나려던 레빈의 눈길이 마주치는 순간',
     '손님들 사이에서 키티와 모자를 든 레빈이 슬픈 눈길을 주고받는다'),
    ('exec-d3724844-51aa-4465-95b1-f4d25e83739e.png', 15, 15, 'prince-argues-marriage',
     '키티의 혼사를 두고 공작과 공작부인이 서재에서 다투는 밤',
     '늙은 공작이 서재에서 화가 난 채 손짓하고 공작부인은 울먹이며 듣는다'),
    ('/LOCAL_USER/.codex/generated_images/01a11967-8d82-7721-ab33-6b1408d60b6b/exec-bf766ebd-a1aa-4f39-b902-6f6b34c11817.png', 16, 9, 'vronsky-walks-home',
     '키티 집에서 나온 뒤 만족스러운 마음으로 눈 덮인 길을 걷는 브론스키',
     '군복 위에 외투를 입은 브론스키가 눈 내린 모스크바 길을 혼자 걸어간다'),
    ('/LOCAL_USER/.codex/generated_images/01a11967-8d82-7721-ab33-6b1408d60b6b/exec-dc2aacfb-d440-4457-ae34-b125bb0193af.png', 17, 35, 'train-arrives',
     '열차가 들어오는 승강장에서 기다리는 브론스키와 스티바',
     '증기를 뿜는 열차가 도착하고 브론스키와 스티바가 승강장에서 객차를 바라본다'),
    ('/LOCAL_USER/.codex/generated_images/01a11967-8d82-7721-ab33-6b1408d60b6b/exec-ac71de2b-0744-4da4-854b-3cec7801c87a.png', 18, 4, 'anna-vronsky-first-glance',
     '기차 객차 문에서 안나와 브론스키가 처음 눈을 마주치는 순간',
     '겨울 여행복의 안나가 객차에서 나오며 길을 비켜 선 브론스키와 잠시 눈을 마주친다'),
    ('/LOCAL_USER/.codex/generated_images/01a11967-8d82-7721-ab33-6b1408d60b6b/exec-222f58ef-29d7-4356-9dd1-378367121799.png', 18, 66, 'anna-bad-omen',
     '철도 사고 뒤 마차에서 불길한 예감을 떨치지 못하는 안나',
     '마차 안에서 눈물을 참는 안나를 스티바가 걱정스럽게 바라본다'),
]

start, stop = map(int, sys.argv[1:3])
assert 0 <= start < stop <= len(ITEMS)
record_path = ROOT / 'illustrations.json'
records = json.loads(record_path.read_text(encoding='utf-8'))
assert len(records) == 20 + start, (len(records), start)
existing_ids = {x['id'] for x in records}
for name, chapter, group, slug, scene, alt in ITEMS[start:stop]:
    item_id = f'p01-c{chapter:02d}-g{group:02d}'
    assert item_id not in existing_ids, item_id
    source = Path(name) if name.startswith('/') else GENERATED / name
    assert source.is_file(), source
    chapter_file = ROOT / f'제1부_제{chapter}장.md'
    assert chapter_file.is_file()
    groups = [x for x in chapter_file.read_text(encoding='utf-8').split('\n\n')
              if x.strip() and not x.lstrip().startswith(('#', '>'))]
    assert group <= len(groups), (chapter_file, group, len(groups))
    base = f'{item_id}-{slug}'
    png = ROOT / 'illustrations' / f'{base}.png'
    jpg = ROOT / 'illustrations' / f'{base}.jpg'
    assert not png.exists() and not jpg.exists()
    shutil.copy2(source, png)
    with Image.open(source) as im:
        im.convert('RGB').save(jpg, 'JPEG', quality=85, optimize=True)
    records.append({'id': item_id, 'chapter_file': chapter_file.name,
                    'after_group': group, 'file': f'illustrations/{jpg.name}',
                    'scene': scene, 'alt': alt})
    existing_ids.add(item_id)
    record_path.write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n',
                           encoding='utf-8')
print(f'Saved and recorded images {start + 1}–{stop}; total {len(records)}.')
