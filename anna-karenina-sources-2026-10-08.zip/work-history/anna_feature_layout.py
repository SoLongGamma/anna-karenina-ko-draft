from pathlib import Path

root = Path('/LOCAL_USER/Documents/ChatGPT/문제해결/anna-karenina-structured')
preview = root / 'make_preview.py'
epub = root / 'build_sample_epub.py'

def replace_once(path, old, new):
    source = path.read_text(encoding='utf-8')
    assert source.count(old) == 1, (path, old[:60], source.count(old))
    path.write_text(source.replace(old, new), encoding='utf-8')

replace_once(preview,
    '  .illustration img { display: block; width: 100%; height: auto; }',
    '  .illustration img { display: block; width: 100%; height: auto; }\n'
    '  .illustration.feature { box-sizing: border-box; width: 100%; min-height: 85vh; margin: 3rem auto; display: flex; align-items: center; }\n'
    '  .illustration.feature img { max-height: 85vh; object-fit: contain; }')
replace_once(preview,
    'body.append("<figure class=\'illustration\'><img src=\'"',
    'body.append("<figure class=\'illustration" + (" feature" if illustration.get("feature_rank") else "") + "\'><img src=\'"')
replace_once(epub,
    '.illustration { page-break-inside: avoid; }',
    '.illustration { page-break-inside: avoid; }\n'
    '.illustration.feature { width: 100%; margin: 0 auto; break-before: page; break-after: page; page-break-before: always; page-break-after: always; }\n'
    '.illustration.feature img { max-height: 85vh; object-fit: contain; }')
replace_once(epub,
    'items.append(\'<figure class="illustration"><img src="images/\'\n',
    'items.append(\'<figure class="illustration\' + (\' feature\' if illustration.get("feature_rank") else \'\') + \'"><img src="images/\'\n')
print('Feature plate layout added to HTML and EPUB builders.')
