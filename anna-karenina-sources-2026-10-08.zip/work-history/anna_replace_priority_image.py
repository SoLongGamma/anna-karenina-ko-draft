from pathlib import Path
from PIL import Image
import json
import shutil
import sys

root = Path('/LOCAL_USER/Documents/ChatGPT/문제해결/anna-karenina-structured')
rank = int(sys.argv[1])
source = Path(sys.argv[2])
assert source.is_file()
records = json.loads((root / 'illustrations.json').read_text(encoding='utf-8'))
item = next(x for x in records if x.get('feature_rank') == rank)
jpg = root / item['file']
png = jpg.with_suffix('.png')
assert jpg.is_file() and png.is_file()
archive = root / 'illustrations' / 'drafts'
archive.mkdir(exist_ok=True)
shutil.copy2(png, archive / png.name)
shutil.copy2(jpg, archive / jpg.name)
shutil.copy2(source, png)
with Image.open(source) as im:
    im.convert('RGB').save(jpg, 'JPEG', quality=85, optimize=True)
print(f'priority {rank} updated; first draft preserved in illustrations/drafts')
