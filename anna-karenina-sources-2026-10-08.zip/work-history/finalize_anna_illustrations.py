from pathlib import Path


ROOT = Path('/LOCAL_USER/Documents/ChatGPT/문제해결/anna-karenina-structured')


def replace_once(name, old, new):
    path = ROOT / name
    content = path.read_text(encoding='utf-8')
    assert content.count(old) == 1, (name, old)
    path.write_text(content.replace(old, new), encoding='utf-8')


replace_once('make_preview.py',
             '  .illustration { float: right; width: 42%; margin: .4rem 0 1.3rem 1.3rem; }',
             '  .illustration { width: min(82%, 32rem); margin: 1.6rem auto 2rem; clear: both; break-inside: avoid; }')
replace_once('make_preview.py',
             '    .illustration { float: none; width: 90%; margin: 1rem auto; } }',
             '    .illustration { width: 94%; margin: 1.3rem auto 1.7rem; } }')
replace_once('build_sample_epub.py',
             '.illustration { float: right; width: 42%; margin: .3em 0 1.2em 1.2em; }',
             '.illustration { width: 82%; margin: 1.5em auto 2em; break-inside: avoid; }')
replace_once('build_sample_epub.py',
             '.illustration::after { content: ""; display: block; clear: both; }',
             '.illustration { page-break-inside: avoid; }')
replace_once('build_sample_epub.py',
             '@media (max-width: 35em) { .illustration { float: none; width: 90%; margin: 1em auto; } }',
             '@media (max-width: 35em) { .illustration { width: 94%; margin: 1.2em auto 1.8em; } }')
replace_once('README.md',
             '- 삽화: 검수한 20장 반영. 제1부 제1장부터 제10장까지의 장면을 불규칙하게 배치했으며, 이어서 작업합니다.',
             '- 삽화: 검수한 30장 반영. 제1부 제1장부터 제16장까지의 장면을 불규칙하게 배치했으며, 이어서 작업합니다.')
replace_once('README.md',
             '다음 위치: 제1부 제10장 76번째 본문 묶음 이후',
             '다음 위치: 제1부 제16장 9번째 본문 묶음 이후')
readme = ROOT / 'README.md'
content = readme.read_text(encoding='utf-8')
entry = '- 2026-10-08: 이전 회차에서 생성 후 미반영된 삽화 9장을 장면·인물·배치 순서에 맞춰 검수했습니다. 한 장의 본문에 없는 유리 장치를 제거했고, 제1부 제16장 삽화 1장을 새로 제작했습니다. 원본 PNG와 EPUB용 JPEG를 보존하고 누적 30장을 기록했습니다. 그림은 본문 옆이 아니라 본문 묶음 사이의 독립된 줄에 놓이도록 미리보기와 EPUB 레이아웃을 갱신했습니다.\n'
assert entry not in content
readme.write_text(content + entry, encoding='utf-8')
replace_once('삽화_작업지침.md',
             '- 검수한 20장은 제1부 제1장부터 제10장까지 배치했습니다.',
             '- 검수한 30장은 제1부 제1장부터 제16장까지 배치했습니다.')
replace_once('삽화_작업지침.md',
             '다음 위치는 제1부 제10장 76번째 본문 묶음 뒤입니다.',
             '다음 위치는 제1부 제16장 9번째 본문 묶음 뒤입니다.')
replace_once('삽화_작업지침.md',
             '넓은 화면에서는 오른쪽에 두어 글이 옆으로 흐르고, 좁은 화면에서는 그림을 한 줄로 내려 읽기 폭을 지킵니다.',
             '넓은 화면과 좁은 화면 모두 그림을 본문 사이의 독립된 줄에 가운데 배치해 문장 구조 들여쓰기의 읽기 폭을 지킵니다.')
replace_once('삽화_작업지침.md',
             '6. 실제 파일이 존재하는 그림만',
             '6. 대화가 길어지더라도 작업이 끊기지 않도록 2~3장마다 원본과 전자책용 파일을 저장하고, 실제 파일이 존재하는 그림만')
print('Updated layout, count, next position, and append-only work log.')
