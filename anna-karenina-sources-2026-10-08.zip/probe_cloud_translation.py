from pathlib import Path
from urllib.request import Request, urlopen
import json
import sys
import time


root = Path(__file__).resolve().parent
model = sys.argv[1] if len(sys.argv) > 1 else "glm-5.3:cloud"
source = (root / "russian_chapters/part01_chapter009.txt").read_text(encoding="utf-8")
sample = source.split("\n\n")[0]
prompt = (
    "당신은 러시아 고전문학 전문 번역가입니다. 다음 러시아어 원문을 출판 가능한 자연스러운 한국어로 완역하세요. "
    "사건, 시점, 비유와 세부 묘사를 생략하거나 덧붙이지 마세요. "
    "인명은 한국어 음역으로, 본문에는 라틴 문자와 한자를 쓰지 마세요. "
    "설명 없이 번역문만 출력하세요.\n\n" + sample
)
payload = json.dumps({
    "model": model,
    "prompt": prompt,
    "stream": True,
    "think": "low",
    "options": {"temperature": 0.25, "num_predict": 1400},
}).encode()
req = Request("http://127.0.0.1:11434/api/generate", payload,
              {"Content-Type": "application/json"})
start = time.monotonic()
pieces = []
with urlopen(req, timeout=180) as res:
    for line in res:
        item = json.loads(line)
        pieces.append(item.get("response", ""))
        if item.get("done"):
            print("model", model)
            print("seconds", round(time.monotonic() - start, 1))
            print("tokens", item.get("eval_count"))
            print("".join(pieces))
            break
