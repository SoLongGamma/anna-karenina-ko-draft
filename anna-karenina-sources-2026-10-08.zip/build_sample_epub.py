from html import escape
from pathlib import Path
import re
import json
from datetime import datetime, timezone
from zipfile import ZIP_DEFLATED, ZIP_STORED, ZipFile


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "안나_카레니나_전권_읽기배치.epub"
COVER = ROOT / "cover.jpg"
SOURCES = sorted(ROOT.glob("제*부_제*장.md"),
                 key=lambda p: tuple(int(n) for n in re.findall(r'\d+', p.stem)))
ILLUSTRATIONS = json.loads((ROOT / "illustrations.json").read_text(encoding="utf-8"))
if not COVER.is_file():
    raise FileNotFoundError("표지를 먼저 만드세요: python3 make_cover.py")
BY_CHAPTER = {}
for illustration in ILLUSTRATIONS:
    path = ROOT / illustration["file"]
    if not path.is_file() or path.suffix.lower() not in {".png", ".jpg", ".jpeg"}:
        raise ValueError(f"삽화 파일 확인 필요: {path}")
    BY_CHAPTER.setdefault(illustration["chapter_file"], {}).setdefault(
        illustration["after_group"], []).append(illustration)


def render(source: Path) -> str:
    items = []
    group = []
    group_number = 0

    def close_group():
        nonlocal group_number
        if group:
            items.append('<section class="group">' + "".join(group) + "</section>")
            group.clear()
            group_number += 1
            for illustration in BY_CHAPTER.get(source.name, {}).get(group_number, []):
                filename = Path(illustration["file"]).name
                items.append('<figure class="illustration' + (' feature' if illustration.get("feature_rank") else '') + '"><img src="images/'
                             + escape(filename, quote=True) + '" alt="'
                             + escape(illustration["alt"], quote=True) + '"/></figure>')

    for raw in source.read_text(encoding="utf-8").splitlines():
        if not raw.strip():
            close_group()
        elif raw.startswith("# "):
            close_group()
            items.append(f"<h1>{escape(raw[2:])}</h1>")
        elif raw.startswith("## "):
            close_group()
            items.append(f"<h2>{escape(raw[3:])}</h2>")
        elif raw.startswith("> "):
            close_group()
            items.append(f'<p class="epigraph">{escape(raw[2:])}</p>')
        elif raw == "레프 톨스토이":
            close_group()
            items.append(f'<p class="author">{escape(raw)}</p>')
        else:
            depth = (len(raw) - len(raw.lstrip(" "))) // 4
            group.append(f'<div class="line depth-{depth}">{escape(raw.strip())}</div>')
    close_group()
    if any(number > group_number for number in BY_CHAPTER.get(source.name, {})):
        raise ValueError(f"삽화 삽입 위치가 본문을 벗어났습니다: {source}")
    return "\n".join(items)


def page(title: str, body: str) -> str:
    return f'''<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="ko" xml:lang="ko">
<head><meta charset="utf-8"/><title>{escape(title)}</title>
<link rel="stylesheet" type="text/css" href="style.css"/></head>
<body><main>{body}</main></body></html>'''


css = """body { margin: 0; background: #fffdf8; color: #28231f;
  font-family: serif; }
main { margin: 0 auto; padding: 1.5em 1em 3em; max-width: 38em; }
.cover-page { padding: 0; max-width: none; text-align: center; }
.cover-page img { display: block; width: 100%; height: auto; max-height: 100vh; object-fit: contain; margin: auto; }
h1 { font-size: 1.6em; margin: 0 0 .3em; }
h2 { font-size: 1.1em; margin: 2.5em 0 1.5em; }
.author { margin: 0; color: #60564f; }
.epigraph { text-align: right; margin: 2em 0; }
.group { margin: 0 0 1.4em; }
.line { line-height: 1.7; overflow-wrap: break-word; }
.illustration { width: 82%; margin: 1.5em auto 2em; break-inside: avoid; }
.illustration img { display: block; width: 100%; height: auto; }
.illustration { page-break-inside: avoid; }
.illustration.feature { width: 100%; margin: 0 auto; break-before: page; break-after: page; page-break-before: always; page-break-after: always; }
.illustration.feature img { max-height: 85vh; object-fit: contain; }
.depth-1 { margin-left: 1.5em; }
.depth-2 { margin-left: 3em; }
.depth-3 { margin-left: 4.5em; }
@media (max-width: 35em) { .illustration { width: 94%; margin: 1.2em auto 1.8em; } }
"""

toc_items = "\n".join(
    f'<li><a href="chapter{number}.xhtml">{escape(source.stem.replace("_", " "))}</a></li>'
    for number, source in enumerate(SOURCES, 1)
)
nav = page("목차", '<h1>목차</h1><nav xmlns:epub="http://www.idpf.org/2007/ops" epub:type="toc" id="toc"><ol>'
           + toc_items + '</ol></nav>')

opf = '''<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" unique-identifier="pub-id" version="3.0" xml:lang="ko">
<metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
<dc:identifier id="pub-id">urn:uuid:82c706cf-f9f7-4bb1-9d40-29b40a1bd839</dc:identifier>
<dc:title>안나 카레니나: 읽기 배치 전권</dc:title>
<dc:creator>레프 톨스토이</dc:creator>
<dc:language>ko</dc:language>
<meta property="dcterms:modified">{modified}</meta>
<dc:source>https://rvb.ru/tolstoy/anna-karenina.htm</dc:source>
</metadata>
<manifest>
<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
<item id="cover-page" href="cover.xhtml" media-type="application/xhtml+xml"/>
<item id="cover-image" href="images/cover.jpg" media-type="image/jpeg" properties="cover-image"/>
{manifest_items}
{image_items}
<item id="css" href="style.css" media-type="text/css"/>
</manifest>
<spine><itemref idref="cover-page"/>{spine_items}</spine>
</package>'''.format(
    modified=datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    manifest_items="\n".join(
        f'<item id="c{number}" href="chapter{number}.xhtml" media-type="application/xhtml+xml"/>'
        for number in range(1, len(SOURCES) + 1)
    ),
    image_items="\n".join(
        f'<item id="im{number}" href="images/{escape(Path(item["file"]).name)}" '
        f'media-type="{("image/png" if Path(item["file"]).suffix.lower() == ".png" else "image/jpeg")}"/>'
        for number, item in enumerate(ILLUSTRATIONS, 1)
    ),
    spine_items="".join(f'<itemref idref="c{number}"/>' for number in range(1, len(SOURCES) + 1)),
)

with ZipFile(OUTPUT, "w") as epub:
    epub.writestr("mimetype", "application/epub+zip", compress_type=ZIP_STORED)
    epub.writestr("META-INF/container.xml", '''<?xml version="1.0" encoding="utf-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
<rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles>
</container>''', compress_type=ZIP_DEFLATED)
    epub.writestr("OEBPS/content.opf", opf, compress_type=ZIP_DEFLATED)
    epub.writestr("OEBPS/style.css", css, compress_type=ZIP_DEFLATED)
    epub.writestr("OEBPS/nav.xhtml", nav, compress_type=ZIP_DEFLATED)
    epub.writestr("OEBPS/cover.xhtml", page("표지", '<div class="cover-page"><img src="images/cover.jpg" alt="안나 카레니나 표지"/></div>'), compress_type=ZIP_DEFLATED)
    epub.write(COVER, "OEBPS/images/cover.jpg", compress_type=ZIP_DEFLATED)
    for number, source in enumerate(SOURCES, 1):
        epub.writestr(f"OEBPS/chapter{number}.xhtml",
                      page(source.stem.replace("_", " "), render(source)),
                      compress_type=ZIP_DEFLATED)
    for illustration in ILLUSTRATIONS:
        epub.write(ROOT / illustration["file"],
                   "OEBPS/images/" + Path(illustration["file"]).name,
                   compress_type=ZIP_DEFLATED)

print(OUTPUT)
