"""Split the downloaded Russian Virtual Library HTML into complete chapters."""

from html import unescape
from pathlib import Path
import json
import re


ROOT = Path(__file__).resolve().parent
DEST = ROOT / "russian_chapters"
DEST.mkdir(exist_ok=True)
INPUTS = [ROOT / "원문_1-4부.html", ROOT / "원문_5-8부.html"]
PARTS = {
    "ЧАСТЬ ПЕРВАЯ": 1,
    "ЧАСТЬ ВТОРАЯ": 2,
    "ЧАСТЬ ТРЕТЬЯ": 3,
    "ЧАСТЬ ЧЕТВЕРТАЯ": 4,
    "ЧАСТЬ ПЯТАЯ": 5,
    "ЧАСТЬ ШЕСТАЯ": 6,
    "ЧАСТЬ СЕДЬМАЯ": 7,
    "ЧАСТЬ ВОСЬМАЯ": 8,
}


def plain(fragment):
    fragment = re.sub(r"<sup[^>]*>.*?</sup>", "", fragment, flags=re.S)
    fragment = re.sub(r"<[^>]+>", "", fragment)
    return re.sub(r"\s+", " ", unescape(fragment)).strip()


manifest = []
for source in INPUTS:
    html = source.read_text(encoding="cp1251")
    blocks = re.split(r'<div class="chapter" id="ch\d+">', html)[1:]
    part = None
    chapter_number = 0
    for block in blocks:
        part_match = re.search(r"<h1>(.*?)</h1>", block, flags=re.S)
        if part_match:
            part = PARTS[plain(part_match.group(1))]
            chapter_number = 0
        assert part is not None
        chapter_number += 1
        title_match = re.search(r"<h2>(.*?)</h2>", block, flags=re.S)
        assert title_match, (source, part, chapter_number)
        title = plain(title_match.group(1))
        cleaned = re.sub(r'<div class="footnote"[^>]*>.*?</div>', '', block, flags=re.S)
        cleaned = re.sub(r'<div class="page"[^>]*>.*?</div>', '', cleaned, flags=re.S)
        paragraphs = []
        for attrs, fragment in re.findall(r"<p([^>]*)>(.*?)</p>", cleaned, flags=re.S):
            text = plain(fragment)
            if not text:
                continue
            if 'class="text-continuation"' in attrs and paragraphs:
                paragraphs[-1] += " " + text
            else:
                paragraphs.append(text)
        assert paragraphs, (source, part, chapter_number)
        path = DEST / f"part{part:02d}_chapter{chapter_number:03d}.txt"
        path.write_text("\n\n".join(paragraphs) + "\n", encoding="utf-8")
        manifest.append({
            "part": part,
            "chapter": chapter_number,
            "source_title": title,
            "paragraphs": len(paragraphs),
            "characters": sum(len(p) for p in paragraphs),
            "path": path.name,
            "source_url": f"https://rvb.ru/tolstoy/01text/vol_{8 if part < 5 else 9}/0031_{1 if part < 5 else 2}-full.htm",
        })

(ROOT / "original_manifest.json").write_text(
    json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(f"Extracted {len(manifest)} chapters across {len(set(x['part'] for x in manifest))} parts")
