from html import escape
from pathlib import Path
import json


ROOT = Path(__file__).resolve().parent
ILLUSTRATIONS = json.loads((ROOT / "illustrations.json").read_text(encoding="utf-8"))
BY_CHAPTER = {}
for illustration in ILLUSTRATIONS:
    BY_CHAPTER.setdefault(illustration["chapter_file"], {}).setdefault(
        illustration["after_group"], []).append(illustration)

PREFIX = """<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>안나 카레니나</title>
<style>
  :root { color-scheme: light; }
  body { margin: 0; background: #f5f1e8; color: #28231f;
         font-family: "Apple SD Gothic Neo", "Noto Serif CJK KR", "Nanum Myeongjo", serif; }
  main { box-sizing: border-box; max-width: 740px; min-height: 100vh; margin: auto;
         padding: 4rem clamp(1.2rem, 6vw, 4rem) 6rem; background: #fffdf8; }
  h1 { font-size: 2rem; margin: 0 0 .4rem; letter-spacing: -.035em; }
  h2 { font-size: 1.1rem; margin: 4rem 0 2rem; font-weight: 600; }
  .author { margin: 0; color: #6e645c; }
  .epigraph { text-align: right; margin: 3rem 0; color: #60564f; }
  .group { margin: 0 0 1.7rem; break-inside: avoid; }
  .line { line-height: 1.72; font-size: 1.08rem; overflow-wrap: anywhere; }
  .illustration { width: min(82%, 32rem); margin: 1.6rem auto 2rem; clear: both; break-inside: avoid; }
  .illustration img { display: block; width: 100%; height: auto; }
  .illustration.feature { box-sizing: border-box; width: 100%; min-height: 85vh; margin: 3rem auto; display: flex; align-items: center; }
  .illustration.feature img { max-height: 85vh; object-fit: contain; }
  .depth-1 { margin-left: 1.6em; }
  .depth-2 { margin-left: 3.2em; }
  .depth-3 { margin-left: 4.8em; }
  @media (max-width: 420px) { .line { font-size: 1rem; }
    .illustration { width: 94%; margin: 1.3rem auto 1.7rem; } }
</style>
</head>
<body><main>
"""

for source in sorted(ROOT.glob("제*부_제*장.md")):
    body = []
    in_group = False
    group_number = 0
    def close_group():
        global in_group, group_number
        if in_group:
            body.append("</section>")
            in_group = False
            group_number += 1
            for illustration in BY_CHAPTER.get(source.name, {}).get(group_number, []):
                body.append("<figure class='illustration" + (" feature" if illustration.get("feature_rank") else "") + "'><img src='"
                            + escape(illustration["file"], quote=True) + "' alt='"
                            + escape(illustration["alt"], quote=True) + "'></figure>")
    for raw in source.read_text(encoding="utf-8").splitlines():
        if not raw.strip():
            close_group()
            continue
        if raw.startswith("# "):
            close_group()
            body.append(f"<h1>{escape(raw[2:])}</h1>")
        elif raw.startswith("## "):
            close_group()
            body.append(f"<h2>{escape(raw[3:])}</h2>")
        elif raw.startswith("> "):
            close_group()
            body.append(f"<p class='epigraph'>{escape(raw[2:])}</p>")
        elif not in_group and raw == "레프 톨스토이":
            body.append(f"<p class='author'>{escape(raw)}</p>")
        else:
            if not in_group:
                body.append("<section class='group'>")
                in_group = True
            depth = (len(raw) - len(raw.lstrip(" "))) // 4
            body.append(f"<div class='line depth-{depth}'>{escape(raw.strip())}</div>")
    close_group()
    output = source.with_suffix(".html")
    output.write_text(PREFIX + "\n".join(body) + "\n</main></body></html>\n", encoding="utf-8")
    print(output)
